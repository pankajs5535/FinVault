using FinVault.Application.DTOs.DisputeDtos;

namespace FinVault.Application.Interfaces.Services
{
    public interface IDisputeService
    {
        // 1 DISPUTE IDENTIFICATION AND CRUD
        Task<IEnumerable<DisputeDto>> GetAllAsync();
        Task<DisputeDto?> GetByIdAsync(int disputeId);
        Task<DisputeDto?> GetByDisputeNumberAsync(string disputeNumber);
        Task<DisputeDto?> GetDisputeDetailsAsync(int disputeId);
        Task<DisputeDto> CreateAsync(CreateDisputeDto dto);
        Task<DisputeDto?> UpdateAsync(UpdateDisputeDto dto);
        Task<bool> DeleteAsync(int disputeId);

        // 2 TRANSACTION-BASED DISPUTES
        Task<IEnumerable<DisputeDto>> GetByTransactionIdAsync(int transactionId);
        Task<IEnumerable<DisputeDto>> GetByCardTransactionIdAsync(int cardTransactionId);

        // 3 CUSTOMER DISPUTE HISTORY
        Task<IEnumerable<DisputeDto>> GetByCustomerIdAsync(int customerId);
        Task<int> CountDisputesByCustomerIdAsync(int customerId);

        // 4 STATUS AND PRIORITY
        Task<IEnumerable<DisputeDto>> GetByStatusAsync(string status);
        Task<IEnumerable<DisputeDto>> GetByPriorityAsync(string priority);
        Task<IEnumerable<DisputeDto>> GetOpenDisputesAsync();
        Task<bool> UpdateStatusAsync(int disputeId, string status);
        Task<bool> UpdatePriorityAsync(int disputeId, string priority);

        // 5 EMPLOYEE ASSIGNMENT
        Task<IEnumerable<DisputeDto>> GetByAssignedEmployeeIdAsync(int employeeId);
        Task<IEnumerable<DisputeDto>> GetUnassignedDisputesAsync();
        Task<bool> AssignToEmployeeAsync(int disputeId, int employeeId);
        Task<bool> UnassignEmployeeAsync(int disputeId);

        // 6 INVESTIGATION AND DEADLINES
        Task<IEnumerable<DisputeDto>> GetOverdueDisputesAsync(DateTime currentDate);
        Task<IEnumerable<DisputeDto>> GetDisputesDueWithinRangeAsync(DateTime startDate, DateTime endDate);
        Task<bool> EscalateAsync(int disputeId);
        Task<bool> GrantProvisionalCreditAsync(int disputeId);
        Task<bool> CloseAsync(int disputeId);

        // 7 RESOLUTION
        Task<bool> ResolveAsync(int disputeId, string resolution, string resolutionNotes);
        Task<IEnumerable<DisputeDto>> GetResolvedDisputesWithinRangeAsync(DateTime startDate, DateTime endDate);
        Task<bool> RejectAsync(int disputeId, string resolutionNotes);

        // 8 DISPUTE TIMELINE
        Task<IEnumerable<DisputeDto>> GetDisputesRaisedWithinRangeAsync(DateTime startDate, DateTime endDate);

        // 9 REFUND MANAGEMENT
        Task<IEnumerable<DisputeDto>> GetDisputesWithRefundsAsync();

        // 10 SEARCH AND VALIDATION
        Task<IEnumerable<DisputeDto>> SearchAsync(string searchTerm);
        Task<bool> IsDisputeNumberExistsAsync(string disputeNumber);
        Task<bool> CanBeDeletedAsync(int disputeId);
    }
}