﻿using FinVault.Application.DTOs.ReconciliationRecordDtos;

namespace FinVault.Application.Interfaces.Services
{
    public interface IReconciliationRecordService
    {
        // 1 RECORD IDENTIFICATION
        Task<IEnumerable<ReconciliationRecordDto>> GetAllAsync();
        Task<ReconciliationRecordDto?> GetByIdAsync(int reconciliationRecordId);
        Task<ReconciliationRecordDto?> GetRecordDetailsAsync(int reconciliationRecordId);
        Task<IEnumerable<ReconciliationRecordDto>> GetByExternalReferenceAsync(string externalReference);
        Task<ReconciliationRecordDto> CreateAsync(CreateReconciliationRecordDto dto);
        Task<ReconciliationRecordDto?> UpdateAsync(UpdateReconciliationRecordDto dto);
        Task<bool> DeleteAsync(int reconciliationRecordId);

        // 2 BATCH AND TRANSACTION RELATIONSHIPS
        Task<IEnumerable<ReconciliationRecordDto>> GetByBatchIdAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetBatchRecordsWithTransactionsAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetByTransactionIdAsync(int transactionId);
        Task<IEnumerable<ReconciliationRecordDto>> GetWithoutTransactionAsync(int reconciliationBatchId);

        // 3 MATCH STATUS
        Task<IEnumerable<ReconciliationRecordDto>> GetByMatchStatusAsync(string matchStatus);
        Task<IEnumerable<ReconciliationRecordDto>> GetMatchedRecordsAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetUnmatchedRecordsAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetAmountMismatchRecordsAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetMissingInBankRecordsAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetMissingInExternalRecordsAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetManuallyResolvedRecordsAsync(int reconciliationBatchId);
        Task<bool> UpdateMatchStatusAsync(int reconciliationRecordId, string matchStatus);

        // 4 AMOUNT AND DATE ANALYSIS
        Task<IEnumerable<ReconciliationRecordDto>> GetRecordsWithDifferencesAsync(int reconciliationBatchId);
        Task<IEnumerable<ReconciliationRecordDto>> GetByExternalDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ReconciliationRecordDto>> GetByExternalAmountRangeAsync(decimal minimumAmount, decimal maximumAmount);

        // 5 RESOLUTION AND AUDIT
        Task<bool> ResolveAsync(int reconciliationRecordId, int resolvedByUserId, string resolutionNotes);
        Task<IEnumerable<ReconciliationRecordDto>> GetByResolvedByUserIdAsync(int userId);
        Task<IEnumerable<ReconciliationRecordDto>> GetResolvedWithinRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ReconciliationRecordDto>> GetUnresolvedRecordsAsync(int reconciliationBatchId);

        // 6 SEARCH AND REPORTING
        Task<IEnumerable<ReconciliationRecordDto>> SearchRecordsAsync(string searchTerm);
        Task<int> CountByBatchAndMatchStatusAsync(int reconciliationBatchId, string matchStatus);
        Task<decimal> GetTotalExternalAmountByBatchAsync(int reconciliationBatchId);
        Task<decimal> GetTotalInternalAmountByBatchAsync(int reconciliationBatchId);
        Task<decimal> GetTotalDifferenceAmountByBatchAsync(int reconciliationBatchId);

        // 7 VALIDATION
        Task<bool> IsExternalReferenceExistsAsync(string externalReference);
        Task<bool> CanBeDeletedAsync(int reconciliationRecordId);
    }
}