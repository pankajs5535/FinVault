﻿using FinVault.Application.DTOs.RefundDtos;

namespace FinVault.Application.Interfaces.Services
{
    public interface IRefundService
    {
        // 1 REFUND IDENTIFICATION AND CRUD
        Task<IEnumerable<RefundDto>> GetAllAsync();
        Task<RefundDto?> GetByIdAsync(int refundId);
        Task<RefundDto?> GetByRefundReferenceAsync(string refundReference);
        Task<RefundDto?> GetRefundDetailsAsync(int refundId);
        Task<RefundDto> CreateAsync(CreateRefundDto dto);
        Task<RefundDto?> UpdateAsync(UpdateRefundDto dto);
        Task<bool> DeleteAsync(int refundId);

        // 2 ORIGINAL TRANSACTION AND DISPUTE HISTORY
        Task<IEnumerable<RefundDto>> GetByOriginalTransactionIdAsync(int originalTransactionId);
        Task<RefundDto?> GetByRefundTransactionIdAsync(int refundTransactionId);
        Task<IEnumerable<RefundDto>> GetByDisputeIdAsync(int disputeId);
        Task<IEnumerable<RefundDto>> GetRefundsWithTransactionsAsync(int originalTransactionId);

        // 3 REFUND STATUS AND TYPE
        Task<IEnumerable<RefundDto>> GetByStatusAsync(string status);
        Task<IEnumerable<RefundDto>> GetRequestedRefundsAsync();
        Task<IEnumerable<RefundDto>> GetApprovedRefundsAsync();
        Task<IEnumerable<RefundDto>> GetProcessedRefundsAsync();
        Task<IEnumerable<RefundDto>> GetRejectedRefundsAsync();
        Task<IEnumerable<RefundDto>> GetFailedRefundsAsync();
        Task<IEnumerable<RefundDto>> GetByRefundTypeAsync(string refundType);
        Task<IEnumerable<RefundDto>> GetOutstandingRefundsAsync();

        // 4 REFUND LIFECYCLE AND APPROVAL
        Task<bool> ApproveAsync(int refundId, int approvedByUserId);
        Task<bool> RejectAsync(int refundId, int approvedByUserId, string rejectionReason);
        Task<bool> ProcessAsync(int refundId, int refundTransactionId);
        Task<bool> MarkAsFailedAsync(int refundId);

        // 5 REQUEST AND APPROVAL AUDIT
        Task<IEnumerable<RefundDto>> GetByRequestedByUserIdAsync(int userId);
        Task<IEnumerable<RefundDto>> GetByApprovedByUserIdAsync(int userId);
        Task<IEnumerable<RefundDto>> GetRequestedWithinRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<RefundDto>> GetProcessedWithinRangeAsync(DateTime startDate, DateTime endDate);

        // 6 FINANCIAL REPORTING
        Task<decimal> GetTotalProcessedAmountByOriginalTransactionIdAsync(int originalTransactionId);
        Task<decimal> GetTotalProcessedAmountByDisputeIdAsync(int disputeId);
        Task<decimal> GetTotalProcessedAmountWithinRangeAsync(DateTime startDate, DateTime endDate);
        Task<int> CountByOriginalTransactionIdAsync(int originalTransactionId);

        // 7 SEARCH AND VALIDATION
        Task<IEnumerable<RefundDto>> SearchAsync(string searchTerm);
        Task<bool> IsRefundReferenceExistsAsync(string refundReference);
        Task<bool> CanBeApprovedAsync(int refundId);
        Task<bool> CanBeProcessedAsync(int refundId);
        Task<bool> CanBeDeletedAsync(int refundId);
        Task<bool> ValidateRefundAmountAsync(int originalTransactionId, decimal refundAmount);
    }
}