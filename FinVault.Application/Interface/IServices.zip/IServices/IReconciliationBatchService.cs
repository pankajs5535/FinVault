﻿using FinVault.Application.DTOs.ReconciliationBatchDtos;

namespace FinVault.Application.Interfaces.Services
{
    public interface IReconciliationBatchService
    {
        // 1 BATCH IDENTIFICATION
        Task<IEnumerable<ReconciliationBatchDto>> GetAllAsync();
        Task<ReconciliationBatchDto?> GetByIdAsync(int reconciliationBatchId);
        Task<ReconciliationBatchDto?> GetByBatchNumberAsync(string batchNumber);
        Task<ReconciliationBatchDto?> GetByFileHashAsync(string fileHash);
        Task<ReconciliationBatchDto?> GetBatchDetailsAsync(int reconciliationBatchId);
        Task<ReconciliationBatchDto> CreateAsync(CreateReconciliationBatchDto dto);
        Task<ReconciliationBatchDto?> UpdateAsync(UpdateReconciliationBatchDto dto);
        Task<bool> DeleteAsync(int reconciliationBatchId);

        // 2 RECONCILIATION TYPE AND BUSINESS DATE
        Task<IEnumerable<ReconciliationBatchDto>> GetByReconciliationTypeAsync(string reconciliationType);
        Task<IEnumerable<ReconciliationBatchDto>> GetByBusinessDateAsync(DateTime businessDate);
        Task<IEnumerable<ReconciliationBatchDto>> GetByTypeAndBusinessDateAsync(string reconciliationType, DateTime businessDate);
        Task<IEnumerable<ReconciliationBatchDto>> GetByBusinessDateRangeAsync(DateTime startDate, DateTime endDate);

        // 3 BATCH STATUS
        Task<IEnumerable<ReconciliationBatchDto>> GetByStatusAsync(string status);
        Task<IEnumerable<ReconciliationBatchDto>> GetPendingBatchesAsync();
        Task<IEnumerable<ReconciliationBatchDto>> GetInProgressBatchesAsync();
        Task<IEnumerable<ReconciliationBatchDto>> GetCompletedBatchesAsync();
        Task<IEnumerable<ReconciliationBatchDto>> GetCompletedWithExceptionsAsync();
        Task<IEnumerable<ReconciliationBatchDto>> GetFailedBatchesAsync();
        Task<bool> StartAsync(int reconciliationBatchId);
        Task<bool> CompleteAsync(int reconciliationBatchId);
        Task<bool> CompleteWithExceptionsAsync(int reconciliationBatchId);
        Task<bool> FailAsync(int reconciliationBatchId, string failureReason);

        // 4 PAYMENT METHOD AND INITIATION
        Task<IEnumerable<ReconciliationBatchDto>> GetByPaymentMethodIdAsync(int paymentMethodId);
        Task<IEnumerable<ReconciliationBatchDto>> GetByInitiatedByUserIdAsync(int userId);

        // 5 RECONCILIATION RESULTS
        Task<IEnumerable<ReconciliationBatchDto>> GetBatchesWithDifferencesAsync();
        Task<IEnumerable<ReconciliationBatchDto>> GetBatchesWithRecordsAsync();
        Task<IEnumerable<ReconciliationBatchDto>> GetCompletedWithinRangeAsync(DateTime startDate, DateTime endDate);

        // 6 SEARCH AND COUNTS
        Task<IEnumerable<ReconciliationBatchDto>> SearchAsync(string searchTerm);
        Task<int> CountByStatusAndBusinessDateAsync(string status, DateTime businessDate);

        // 7 VALIDATION AND DUPLICATE PREVENTION
        Task<bool> IsBatchNumberExistsAsync(string batchNumber);
        Task<bool> IsFileHashExistsAsync(string fileHash);
        Task<bool> CanBeStartedAsync(int reconciliationBatchId);
        Task<bool> CanBeCompletedAsync(int reconciliationBatchId);
        Task<bool> CanBeDeletedAsync(int reconciliationBatchId);
    }
}